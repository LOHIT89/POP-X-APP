import React, { useState } from 'react';
import './RegisterPage.css';

function RegisterPage({ navigate }) {
  const [formData, setFormData] = useState({
    fullName: '',
    phone: '',
    email: '',
    password: '',
    companyName: '',
    isAgency: 'yes',
  });

  const handleChange = (field) => (e) => {
    setFormData((prev) => ({ ...prev, [field]: e.target.value }));
  };

  const handleSubmit = () => {
    navigate('account', {
      name: formData.fullName || 'Marry Doe',
      email: formData.email || 'Marry@Gmail.Com',
    });
  };

  return (
    <div className="register-page">
      <div className="register-content">
        <h1 className="register-title">
          Create your<br />PopX account
        </h1>

        <div className="form-group">
          <label className="form-label required">Full Name</label>
          <input
            type="text"
            className="form-input"
            placeholder="Marry Doe"
            value={formData.fullName}
            onChange={handleChange('fullName')}
          />
        </div>

        <div className="form-group">
          <label className="form-label required">Phone number</label>
          <input
            type="tel"
            className="form-input"
            placeholder="Marry Doe"
            value={formData.phone}
            onChange={handleChange('phone')}
          />
        </div>

        <div className="form-group">
          <label className="form-label required">Email address</label>
          <input
            type="email"
            className="form-input"
            placeholder="Marry Doe"
            value={formData.email}
            onChange={handleChange('email')}
          />
        </div>

        <div className="form-group">
          <label className="form-label required">Password</label>
          <input
            type="password"
            className="form-input"
            placeholder="Marry Doe"
            value={formData.password}
            onChange={handleChange('password')}
          />
        </div>

        <div className="form-group">
          <label className="form-label">Company name</label>
          <input
            type="text"
            className="form-input"
            placeholder="Marry Doe"
            value={formData.companyName}
            onChange={handleChange('companyName')}
          />
        </div>

        <div className="agency-group">
          <p className="agency-label">
            Are you an Agency?<span className="req-star">*</span>
          </p>
          <div className="radio-group">
            <label className="radio-option">
              <input
                type="radio"
                name="agency"
                value="yes"
                checked={formData.isAgency === 'yes'}
                onChange={handleChange('isAgency')}
              />
              <span className="radio-custom"></span>
              <span className="radio-text">Yes</span>
            </label>
            <label className="radio-option">
              <input
                type="radio"
                name="agency"
                value="no"
                checked={formData.isAgency === 'no'}
                onChange={handleChange('isAgency')}
              />
              <span className="radio-custom"></span>
              <span className="radio-text">No</span>
            </label>
          </div>
        </div>

        <button className="create-btn" onClick={handleSubmit}>
          Create Account
        </button>
      </div>
    </div>
  );
}

export default RegisterPage;
