import React, { useState } from 'react';
import './LoginPage.css';

function LoginPage({ navigate }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    navigate('account', {
      name: 'Marry Doe',
      email: email || 'Marry@Gmail.Com',
    });
  };

  const isFormFilled = email.trim() !== '' && password.trim() !== '';

  return (
    <div className="login-page">
      <div className="login-content">
        <h1 className="login-title">
          Signin to your<br />PopX account
        </h1>
        <p className="login-subtitle">
          Lorem ipsum dolor sit amet,<br />
          consectetur adipiscing elit,
        </p>

        <div className="form-group">
          <label className="form-label">Email Address</label>
          <input
            type="email"
            className="form-input"
            placeholder="Enter email address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <div className="form-group">
          <label className="form-label">Password</label>
          <input
            type="password"
            className="form-input"
            placeholder="Enter password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>

        <button
          className={`login-btn ${isFormFilled ? 'login-btn--active' : ''}`}
          onClick={handleLogin}
        >
          Login
        </button>
      </div>
    </div>
  );
}

export default LoginPage;
