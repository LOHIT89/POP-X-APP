import React from 'react';
import './AccountSettingsPage.css';

function AccountSettingsPage({ navigate, userData }) {
  const name = userData?.name || 'Marry Doe';
  const email = userData?.email || 'Marry@Gmail.Com';

  return (
    <div className="account-page">
      <div className="account-header">
        <h2 className="account-heading">Account Settings</h2>
      </div>

      <div className="profile-card">
        <div className="avatar-wrapper">
          <div className="avatar">
            <img
              src="https://randomuser.me/api/portraits/women/44.jpg"
              alt="Profile"
              className="avatar-img"
            />
          </div>
          <button className="camera-btn" aria-label="Change photo">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none">
              <path
                d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"
                stroke="white"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <circle cx="12" cy="13" r="4" stroke="white" strokeWidth="2" />
            </svg>
          </button>
        </div>

        <div className="profile-info">
          <p className="profile-name">{name}</p>
          <p className="profile-email">{email}</p>
        </div>
      </div>

      <div className="account-divider" />

      <div className="account-bio">
        <p>
          Lorem Ipsum Dolor Sit Amet, Consetetur Sadipscing Elitr, Sed Diam
          Nonumy Eirmod Tempor Invidunt Ut Labore Et Dolore Magna Aliquyam
          Erat, Sed Diam
        </p>
      </div>

      <div className="account-divider" />
    </div>
  );
}

export default AccountSettingsPage;
