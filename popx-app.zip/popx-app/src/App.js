import React, { useState } from 'react';
import WelcomePage from './pages/WelcomePage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import AccountSettingsPage from './pages/AccountSettingsPage';
import './App.css';

function App() {
  const [currentPage, setCurrentPage] = useState('welcome');
  const [userData, setUserData] = useState(null);

  const navigate = (page, data = null) => {
    if (data) setUserData(data);
    setCurrentPage(page);
  };

  return (
    <div className="app-shell">
      <div className="mobile-frame">
        {currentPage === 'welcome' && (
          <WelcomePage navigate={navigate} />
        )}
        {currentPage === 'login' && (
          <LoginPage navigate={navigate} />
        )}
        {currentPage === 'register' && (
          <RegisterPage navigate={navigate} />
        )}
        {currentPage === 'account' && (
          <AccountSettingsPage navigate={navigate} userData={userData} />
        )}
      </div>
    </div>
  );
}

export default App;
