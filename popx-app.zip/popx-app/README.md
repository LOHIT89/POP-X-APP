# PopX App

A pixel-perfect React implementation of the PopX mobile UI design, centered on the webpage with seamless page navigation.

## Screens Implemented

1. **Welcome Page** — Landing screen with "Create Account" and "Login" CTAs
2. **Login Page** — Email + password form with conditional button activation
3. **Register Page** — Full registration form with radio button for agency selection
4. **Account Settings Page** — Profile card with avatar, camera upload button, and bio

## Tech Stack

- React 18
- CSS Modules (plain CSS per component)
- Google Fonts — Sora

## Getting Started

```bash
npm install
npm start
```

Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

## Build for Production

```bash
npm run build
```

## Deploy to Vercel

1. Push this repo to GitHub
2. Import to [vercel.com](https://vercel.com)
3. Vercel auto-detects Create React App — click Deploy

## Design Notes

- Mobile frame (390×844px) is centered on desktop with rounded corners and shadow
- Fully responsive: full-screen on mobile viewports (≤430px)
- Navigation is state-driven via a `navigate(page, data)` function passed as prop
- Purple accent color: `#6c35de`
